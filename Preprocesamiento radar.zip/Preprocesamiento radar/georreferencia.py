

import numpy as np

import PIL

from PIL import Image

from datetime import timedelta, date

import os

import pyproj

def rgb(b,g,r):  #funcion arbitraria que toma los valores de RGB de los pixeles y los pasa a una intensidad 0 -1 
 if r < 230:
  if b > 230:
   f=0.16*(1+g/255)
  else: 
   if g < 10:
    f=0
   else:
    f=0.25*(1+g/255)
 else:
  f=0.66*(1+(np.abs(g-r))/255)
 return f




array=np.zeros((480,480))
os.chdir(YOUR ROOT)
fechas_horas=['20190912_0000','20190912_0010','20190912_0020','20190912_0030','20190912_0040','20190912_0050','20190912_0100','20190912_0110','20190912_0120','20190912_0130']
# fechas_horas contiene nombres de archivos de imágenes de radar

for k in range(0,len(fechas_horas)):
 fecha_hora=fechas_horas[k]
 pil_image=PIL.Image.open(fecha_hora+".gif").convert('RGB')           # ejemplo abre un imagen
 open_cv_image = np.array(pil_image)
 open_cv_image = open_cv_image[:, :, ::-1].copy()    #convierte de  rgb a bgr para el argumento de la función
 open_cv_image = open_cv_image[0:480,:,:]  # quita la parte inferior de la imagen
 for j in range(0,480):
  for k in range(0,480): 
   array[j,k]=rgb(open_cv_image[j,k,0],open_cv_image[j,k,1],open_cv_image[j,k,2])  #

 

 #La parte de georreferenciación: Las imágenes están en proyección 30T UTM y cada pixel equivale a un kilómetro (resolución espacial de la imagen). La siguiente parte de código toma las coordenadas del radar y genera un grid rectangular cuyos valores geolocalizan los píxeles



lon_radar=-0.546  #coords radar zaragoza
lat_radar=41.734

# generamos grid en x e y en coordenadas utm
sitecoords = ( lon_radar,lat_radar)   
p=pyproj.Proj(proj='utm',zone=30, ellps='WGS84')  #cambio a utm
sitecoords_utm=p(sitecoords[0],sitecoords[1])
Ymin=int(np.round(sitecoords_utm[1],0)-240000)
Ymax=int(np.round(sitecoords_utm[1],0)+240000)
Xmin=int(np.round(sitecoords_utm[0],0)-240000)
Xmax=int(np.round(sitecoords_utm[0],0)+240000)

GRID = np.array([(x, y)  for y in range(Ymin,Ymax,1000) for x in range(Xmin,Xmax,1000)])   
GRID=np.flip(np.reshape(GRID,(480,480,2)),0)   

GRID_EXPORT=np.asarray([np.round(GRID[:,:,0],1),np.round(GRID[:,:,1],1),np.round(array,3)])  # combinamos el GRID construido con la información de la imagen 
GRID_EXPORT_=np.transpose(np.reshape(GRID_EXPORT,(3,480*480)))
